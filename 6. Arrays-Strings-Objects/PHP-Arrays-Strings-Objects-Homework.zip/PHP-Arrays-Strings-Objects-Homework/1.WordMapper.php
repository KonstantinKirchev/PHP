<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Word Mapper</title>
</head>

<body>
<form method="post" action="Problem1.Result.php">
    <textarea rows="4" cols="50" name="text">The quick brows fox.!!! jumped over..// the lazy dog.!</textarea>
    <br/>
    <input type="submit" value="Count Words" name="submit"/>
</form>
</body>
</html>
