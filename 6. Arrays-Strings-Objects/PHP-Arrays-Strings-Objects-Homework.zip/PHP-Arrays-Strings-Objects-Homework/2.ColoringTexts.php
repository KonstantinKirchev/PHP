<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Coloring Texts</title>
</head>
<body>
<form method="post" action="Problem2.Result.php">
    <textarea name="text" id="text" cols="20" rows="4">What a wonderful world!</textarea>
    <br/>
    <input type="submit" name="submit" value="Color Text"/>
</form>
</body>
</html>
