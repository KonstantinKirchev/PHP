<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sidebar Builder</title>
</head>
<body>
<form action="Problem3.Result.php" method="post">
    Categories: <input type="text" name="categories"/><br/>
    Tags: <input type="text" name="tags"/><br/>
    Months: <input type="text" name="months"/><br/>
    <input type="submit" name="submit" value="Generate"/>
</form>
</body>
</html>