<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>InformationTable</title>
    <style>
        body > table > tbody > tr > td{
            border: 1px solid black;
        }
        body > table > tbody > tr > td:nth-child(1){
            background-color: orange;
        }
        body > table > tbody > tr > td:nth-child(2){
            text-align: right;
        }
        body > table{
            border-collapse: collapse;
        }
    </style>
</head>
<body>
<table cellspacing="0" >
    <?php
    $name = 'Konstantin';
    $phoneNumber = '0882-321-423';
    $age = 24;
    $address = 'Hadji Dimitar';
    for ($i = 0; $i < 4; $i++) {
        if ($i==0) {
            echo "<tr>";
            echo "<td>Name</td>";
            echo "<td>$name</td>";
            echo "</tr>";
        }else if ($i==1) {
            echo "<tr>";
            echo "<td>Phone number</td>";
            echo "<td>$phoneNumber</td>";
            echo "</tr>";
        }else if ($i==2) {
            echo "<tr>";
            echo "<td>Age</td>";
            echo "<td>$age</td>";
            echo "</tr>";
        }else if ($i==3) {
            echo "<tr>";
            echo "<td>Address</td>";
            echo "<td>$address</td>";
            echo "</tr>";
        }
    }
    ?>
</table>
</body>
</html>

