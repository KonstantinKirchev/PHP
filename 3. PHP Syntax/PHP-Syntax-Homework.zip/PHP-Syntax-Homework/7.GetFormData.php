<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>GetFormData</title>
</head>
<body>
<form method="get">
    <input type="text" name="name" placeholder="Name.."/><br>
    <input type="text" name="age" placeholder="Age.."/><br>
    <input type="radio" name="sex" value="male">Male<br>
    <input type="radio" name="sex" value="female">Female<br>
    <input type="submit" name="submit"/>
</form>
<?php
    $name = '';
    $age = '';
    $sex = '';
    if (isset($_GET['submit'])) {
        $name = $_GET['name'];
        $age = $_GET['age'];
        $sex = $_GET['sex'];
        echo "My name is " .htmlentities($name). ". I am " .htmlentities($age). " years old. I am " .htmlentities($sex).".";
    }
?>
</body>
</html>