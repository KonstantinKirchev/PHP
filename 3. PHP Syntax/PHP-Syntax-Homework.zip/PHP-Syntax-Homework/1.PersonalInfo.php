<?php
$firstName = 'Konstantin';
$lastName = 'Kirchev';
$fullName = $firstName .' '. $lastName;
$age = 33;
echo "My name is {$firstName} {$lastName} and I am {$age} years old.\n";
echo "My name is {$fullName} and I am {$age} years old.";
?>